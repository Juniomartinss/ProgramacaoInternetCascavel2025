let resultado = document.querySelector("#resultado");
let inputValorPago = document.querySelector("#inputValorPago");
let inputPrecoProduto = document.querySelector("#inputPrecoProduto");
let btCalcularTroco = document.querySelector("#btCalcularTroco");

// Função que calcula o troco
function CalcularTroco() {
    let valorPago = Number (inputValorPago.value);
    let precoProduto = Number(inputPrecoProduto.value);
    let troco = valorPago - precoProduto;

    resultado.textContent = "Troco:" + troco;
}

btCalcularTroco.onclick = CalcularTroco;