// Pegando os elementos HTML do DOM
let resultado = document.querySelector("#resultado");
let inputValorPago = document.querySelector("#inputValorPago");
let inputPrecoProduto = document.querySelector("#inputPrecoProduto");
let btCalcularTroco = document.querySelector("#btCalcularTroco");

// Função que será chamada quando o botão for clicado
function CalcularTroco(){
        // Pegando os valores inseridos pelos usuários e convertendo para número
        let num1 = Number (inputValorPago.value);
        let num2 = Number (inputPrecoProduto.value);
        let troco = num1 - num2;
         
        // Mostrando o resultado no elemento <h1> da página
        resultado.textContent = "troco:" + troco;
}

// Quando o botão for clicado, chama a função calcularTroco
btCalcularTroco.onclick = CalcularTroco