// Pegando os elementos corretamente
let resultado = document.querySelector("#resultado");
let inputNumero1 = document.querySelector("#inputNumero1");
let inputNumero2 = document.querySelector("#inputNumero2");
let btSomar = document.querySelector("#btSomar");

// Função para somar os números
function somar() {
   // Aqui usamos .value para pegar o valor digitado
   let n1 = Number(inputNumero1.value);
   let n2 = Number(inputNumero2.value);
   
   let soma = n1 + n2;

   // Exibe o resultado
   resultado.textContent = "Resultado: " + soma;
}

// Atribui a função ao evento de clique
btSomar.onclick = somar;